fpn=[]
checkintime =[]
checkinday=[]
hoursleftin=[]
discount=[]
price=[]
pricepaid=[]
total_price_paid = 0

start_of_day= input("Is it the start of the day?")
while True:
    if start_of_day in ['y',"Y",'Yes','yes']:
      total_price = 0 
      break
    elif start_of_day in ['n','N','No','no']:
      break
    else: 
      print("Try again")
      start_of_day= input("Is it the start of the day?") 
for x in range (10000):
  while True:
    checkintimevar = int(input("Time (24 hour clock, hour only)"))
    if checkintimevar > 24 or checkintimevar < 8:
      print("try again, parking is closed.")
    else: 
      print("number accepted")
      checkintime.append(checkintimevar)
      break
  while True:
    checkindayvar= str(input("Day of check in, first two letters, first letter in caps."))
    if checkindayvar not in ("Mo","Tu","We","Th","Fr","Sa","Su"):
      print("try again, error.")
    else: 
      print("value accepted")
      checkinday.append(checkindayvar)
      break
  while True:
    hoursleftinvar= int(input("Number of hours left in parking, number only."))
    if hoursleftinvar < 0 or hoursleftinvar > 8:
      print("try again, error.")
    elif checkindayvar == 'Su' and checkintimevar < 16:
      print('try again, error.')
    elif checkindayvar in ['Mo', 'Tu', 'We', 'Th', 'Fr'] and hoursleftinvar > 2 and checkintimevar < 16:
      print("try again, error.")
    elif checkindayvar == 'Sa' and hoursleftinvar > 4 and checkintimevar < 16:
      print('try again, error.')
    else:
      print("value accepted.")
      hoursleftin.append(hoursleftinvar)
      break
  while True:
    entryfpn= input("Would you like to enter a frequent parking number?")
    if entryfpn not in ["Yes", "No","Y","N","yes","no","y","n"]:
      print("error, try again")
    elif entryfpn in ["No","n","N","no"]:
      fpn.append("-")
      break
    elif entryfpn in ["Yes","y","yes","Y"]:
      fpnvar = int(input("Please enter your frequent parking number."))
      rem = 0
      strlist = []
      count = 0
      for i in range (0,4):
        myfpnvar = str(fpnvar)
        strlist.append((myfpnvar[i]))
        adds = int(myfpnvar[i])*(5-i)
        count = count + adds
        rem = myfpnvar[4]
      if 11-count%11 != int(rem):
        print("Error, you will get to choose to apply a frequent parking number or not again.")
      else:
        print("valid parking number")
        fpn.append(fpnvar)
        break
  while True:
    pricevar = 0
    if checkintime[x] < 16:
      firsthalfcalc = 16-checkintime[x]
      if firsthalfcalc > hoursleftin[x]:
        firsthalfcalc = hoursleftin[x]
      secondhalfcalc= hoursleftin[x]-firsthalfcalc
      if checkinday[x] == 'Su' and (fpn[x]) != "-" and checkintime[x] < 16:
        pricevar = 2*hoursleftin[x]*0.5
        price.append(pricevar)
        discount.append(pricevar)
        break
      elif checkinday[x] == 'Su' and (fpn[x]) == '-' and checkintime[x] < 16:
        pricevar = 2*hoursleftin[x]
        price.append(pricevar)
        discount.append(0)
        break
      elif checkinday [x] in ['Mo', 'Tu', 'We', 'Th', 'Fr'] and (fpn[x]) != "-" and checkintime[x] < 16:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 10*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (10*firsthalfcalc*0.5) + (2*secondhalfcalc*0.5)
          price.append(pricevar)
          discount.append(pricevar)
          break
      elif checkinday [x] in ['Mo', 'Tu', 'We', 'Th', 'Fr'] and (fpn[x]) == '-' and checkintime[x] < 16:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 10*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else:
          pricevar = (10*firsthalfcalc) + (2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
      elif checkinday[x] == 'Sa' and (fpn[x]) != "-" and checkintime[x] < 16:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 3*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (3*firsthalfcalc*0.5) + (2*secondhalfcalc*0.5) 
          price.append(pricevar)
          discount.append(pricevar)
          break
      elif checkinday[x] == 'Sa' and (fpn[x]) == '-' and checkintime[x] < 16:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 3*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else: 
          pricevar = (3*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
      elif (fpn[x]) != "-":
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 2*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (2*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(pricevar)
          break
      else:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 2*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else:
          pricevar = (2*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
    else:
      firsthalfcalc = 0
      secondhalfcalc = hoursleftin[x]
      if checkinday[x] == 'Su' and (fpn[x]) != "-":
        pricevar = 2*hoursleftin[x]*0.5
        price.append(pricevar)
        discount.append(pricevar)
        break
      elif checkinday[x] == 'Su' and (fpn[x]) == '-':
        pricevar = 2*hoursleftin[x]
        price.append(pricevar)
        discount.append(0)
        break
      elif checkinday [x] in ['Mo', 'Tu', 'We', 'Th', 'Fr'] and (fpn[x]) != "-":
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 10*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (10*firsthalfcalc*0.5) + (2*secondhalfcalc*0.5)
          price.append(pricevar)
          discount.append(pricevar)
          break
      elif checkinday [x] in ['Mo', 'Tu', 'We', 'Th', 'Fr'] and (fpn[x]) == '-':
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 10*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else:
          pricevar = (10*firsthalfcalc) + (2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
      elif checkinday[x] == 'Sa' and (fpn[x]) != "-":
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 3*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (3*firsthalfcalc*0.5) + (2*secondhalfcalc*0.5) 
          price.append(pricevar)
          discount.append(pricevar)
          break
      elif checkinday[x] == 'Sa' and (fpn[x]) == '-':
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 3*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else: 
          pricevar = (3*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
      elif (fpn[x]) != "-":
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 2*hoursleftin[x]*0.5
          price.append(pricevar)
          discount.append(pricevar)
          break
        else:
          pricevar = (2*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(pricevar)
          break
      else:
        if firsthalfcalc == hoursleftin[x]:
          pricevar = 2*hoursleftin[x]
          price.append(pricevar)
          discount.append(0)
          break
        else:
          pricevar = (2*firsthalfcalc)+(2*secondhalfcalc)
          price.append(pricevar)
          discount.append(0)
          break
  while True: 
    pricepaidvar = int(input("How much are you going to pay?"))
    if pricepaidvar >= price[x]:
      print("valid")
      pricepaid.append(pricepaidvar)
      total_price_paid += pricepaidvar
      break
    else:
      print("error. try again. try not to scam the parking company this time.")
  while True:
    end_of_day= input('is it the end of the day?')
    if end_of_day in ['n','N','No','no']: 
      print("----------","\n","daily total paid in pounds (£):", total_price_paid)
      break
    elif end_of_day not in ['y','Y', 'yes','Yes']:
      print("Try again")
      end_of_day= input("Is it the end of the day?")
    else: 
      print("----------","\n","daily total paid in pounds (£):", total_price_paid)
      total_price_paid = 0
      break
  print("check in time:", checkintime[x], "\n", "check in day:", checkinday[x], "\n", "hours left in parking:", hoursleftin[x], "\n", "frequent parking number:", fpn[x], "\n", "discount given in pounds(£):", discount[x], "\n", "price in pounds (£):", price[x], '\n', "----------",'firsthalfcalc', firsthalfcalc, 'secondhalfcalc', secondhalfcalc) 
#valid = 43214
#invalid fpn is 12314
